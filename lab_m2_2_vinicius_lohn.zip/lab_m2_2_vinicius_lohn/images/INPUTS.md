# Imagens de entrada

- `macas_favoravel.png`: cena com três maçãs verdes sobre fundo neutro e iluminação relativamente uniforme.
- `macas_desafio.png`: cena com cinco maçãs verdes sobre mesa de madeira, com sombras, reflexos e folhas.

As duas cenas foram criadas digitalmente para os experimentos deste projeto e são mantidas sem alterações em `images/input/`. A utilização está limitada à atividade didática e à demonstração dos métodos implementados.
