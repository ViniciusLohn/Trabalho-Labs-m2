#!/usr/bin/env python3
"""Ferramenta de linha de comando para os laboratórios M2.1 e M2.2 de PDI."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np

METHODS = ("fixed", "otsu", "adaptive", "hsv")
MORPH_SHAPES = ("ellipse", "rect", "cross")


def _odd_kernel(value: int, name: str, allow_zero: bool = False) -> int:
    if allow_zero and value == 0:
        return value
    if value < 3 or value % 2 == 0:
        raise ValueError(f"{name} deve ser ímpar e >= 3" + (" ou 0" if allow_zero else ""))
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pdi_lab",
        description="Segmentação binária e análise de componentes conexos (M2.1/M2.2).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--input", required=True, help="imagem de entrada ou máscara binária")
    parser.add_argument("--output", required=True, help="caminho da máscara (segment) ou prefixo das saídas (analyze)")
    parser.add_argument("--operation", required=True, choices=("segment", "analyze"), help="operação solicitada")
    parser.add_argument("--config", help="arquivo JSON com parâmetros padrão")

    parser.add_argument("--method", choices=METHODS, default=None, help="método de segmentação (segment)")
    parser.add_argument("--threshold", type=int, default=120, help="limiar global para fixed (0 a 255)")
    parser.add_argument("--invert", action="store_true", help="inverte a polaridade de fixed/otsu/adaptive")
    parser.add_argument("--block-size", type=int, default=11, help="janela ímpar para adaptive (>=3)")
    parser.add_argument("--c", type=float, default=2.0, help="constante subtraída da média local em adaptive")
    parser.add_argument("--hmin", type=int, default=25, help="matiz mínima HSV (0 a 179)")
    parser.add_argument("--hmax", type=int, default=85, help="matiz máxima HSV (0 a 179); hmin>hmax cruza 179/0")
    parser.add_argument("--smin", type=int, default=70, help="saturação mínima HSV (0 a 255)")
    parser.add_argument("--smax", type=int, default=255, help="saturação máxima HSV (0 a 255)")
    parser.add_argument("--vmin", type=int, default=35, help="valor/brilho mínimo HSV (0 a 255)")
    parser.add_argument("--vmax", type=int, default=255, help="valor/brilho máximo HSV (0 a 255)")
    parser.add_argument("--blur", type=int, default=0, help="kernel Gaussiano ímpar antes da segmentação; 0 desativa")

    parser.add_argument("--connectivity", type=int, choices=(4, 8), default=8, help="conectividade para os CSVs e rótulos")
    parser.add_argument("--min-area", type=int, default=1000, help="área mínima em pixels para manter um componente")
    parser.add_argument("--open-shape", choices=MORPH_SHAPES, default="ellipse", help="forma do elemento estruturante da abertura")
    parser.add_argument("--open-kernel", type=int, default=5, help="tamanho ímpar do kernel da abertura")
    parser.add_argument("--open-iterations", type=int, default=1, help="iterações da abertura")
    parser.add_argument("--close-shape", choices=MORPH_SHAPES, default="ellipse", help="forma do elemento estruturante do fechamento")
    parser.add_argument("--close-kernel", type=int, default=7, help="tamanho ímpar do kernel do fechamento")
    parser.add_argument("--close-iterations", type=int, default=1, help="iterações do fechamento")
    return parser


def _apply_config(args: argparse.Namespace, parser: argparse.ArgumentParser, argv: list[str]) -> None:
    if not args.config:
        return
    config_path = Path(args.config)
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise OSError(f"não foi possível ler a configuração: {config_path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON inválido em {config_path}: {exc}") from exc

    section = config.get(args.operation, {})
    if not isinstance(section, dict):
        raise ValueError(f"a seção '{args.operation}' em {config_path} deve ser um objeto JSON")

    explicit: set[str] = set()
    option_actions = parser._option_string_actions
    for token in argv:
        option = token.split("=", 1)[0]
        action = option_actions.get(option)
        if action is not None:
            explicit.add(action.dest)

    valid_keys = {action.dest for action in parser._actions}
    for key, value in section.items():
        dest = key.replace("-", "_")
        if dest not in valid_keys or dest in {"input", "output", "operation", "config", "help"}:
            raise ValueError(f"parâmetro desconhecido na seção '{args.operation}' de {config_path}: {key}")
        if dest not in explicit:
            setattr(args, dest, value)


def validate_args(args: argparse.Namespace) -> None:
    if args.operation == "segment":
        if args.method not in METHODS:
            raise ValueError("--method é obrigatório para --operation segment")
        if not 0 <= args.threshold <= 255:
            raise ValueError("--threshold deve estar entre 0 e 255")
        _odd_kernel(args.blur, "--blur", allow_zero=True)
        if args.method == "adaptive":
            _odd_kernel(args.block_size, "--block-size")
        for name in ("hmin", "hmax"):
            value = getattr(args, name)
            if not 0 <= value <= 179:
                raise ValueError(f"--{name} deve estar entre 0 e 179 (faixa H do OpenCV)")
        for name in ("smin", "smax", "vmin", "vmax"):
            value = getattr(args, name)
            if not 0 <= value <= 255:
                raise ValueError(f"--{name} deve estar entre 0 e 255")
        if args.smin > args.smax:
            raise ValueError("--smin não pode ser maior que --smax")
        if args.vmin > args.vmax:
            raise ValueError("--vmin não pode ser maior que --vmax")
        if args.method == "adaptive" and args.c < 0:
            raise ValueError("--c deve ser maior ou igual a 0 neste projeto")
    else:
        if args.connectivity not in (4, 8):
            raise ValueError("--connectivity aceita somente 4 ou 8")
        if not isinstance(args.min_area, int) or args.min_area < 0:
            raise ValueError("--min-area deve ser um inteiro não negativo")
        _odd_kernel(args.open_kernel, "--open-kernel")
        _odd_kernel(args.close_kernel, "--close-kernel")
        for name in ("open_iterations", "close_iterations"):
            value = getattr(args, name)
            if not isinstance(value, int) or value < 1:
                raise ValueError(f"--{name.replace('_', '-')} deve ser um inteiro >= 1")
        if args.open_shape not in MORPH_SHAPES or args.close_shape not in MORPH_SHAPES:
            raise ValueError("forma morfológica inválida")


def segment_image(image: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    """Retorna máscara uint8 2D com valores exclusivos 0 e 255."""
    working = image
    if args.blur:
        working = cv2.GaussianBlur(working, (args.blur, args.blur), 0)

    if args.method == "hsv":
        hsv = cv2.cvtColor(working, cv2.COLOR_BGR2HSV)
        lower1 = np.array([args.hmin, args.smin, args.vmin], dtype=np.uint8)
        upper1 = np.array([args.hmax, args.smax, args.vmax], dtype=np.uint8)
        if args.hmin <= args.hmax:
            mask = cv2.inRange(hsv, lower1, upper1)
        else:
            upper_a = np.array([179, args.smax, args.vmax], dtype=np.uint8)
            lower_b = np.array([0, args.smin, args.vmin], dtype=np.uint8)
            mask_a = cv2.inRange(hsv, lower1, upper_a)
            mask_b = cv2.inRange(hsv, lower_b, upper1)
            mask = cv2.bitwise_or(mask_a, mask_b)
        return mask

    gray = cv2.cvtColor(working, cv2.COLOR_BGR2GRAY)
    if args.method == "fixed":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        _, mask = cv2.threshold(gray, args.threshold, 255, mode)
    elif args.method == "otsu":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        _, mask = cv2.threshold(gray, 0, 255, mode | cv2.THRESH_OTSU)
    elif args.method == "adaptive":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        mask = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, mode, args.block_size, args.c
        )
    else:
        raise ValueError(f"método desconhecido: {args.method}")
    return mask


def _read_mask(path: Path) -> np.ndarray:
    mask = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if mask is None:
        raise OSError(f"não foi possível ler a máscara: {path}")
    if mask.ndim != 2:
        raise ValueError("a entrada de analyze deve ser uma máscara de canal único")
    if mask.size == 0:
        raise ValueError("a máscara de entrada está vazia")
    values = set(int(v) for v in np.unique(mask))
    if not values.issubset({0, 255}):
        raise ValueError(f"a máscara deve conter somente 0 e 255; valores encontrados: {sorted(values)}")
    return mask


def _connected_components(mask: np.ndarray, connectivity: int) -> tuple[int, np.ndarray, np.ndarray, np.ndarray]:
    count_including_background, labels, stats, centroids = cv2.connectedComponentsWithStats(
        mask, connectivity=connectivity, ltype=cv2.CV_32S
    )
    return count_including_background - 1, labels, stats, centroids


def _component_records(mask: np.ndarray, connectivity: int, min_area: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    count, _labels, stats, centroids = _connected_components(mask, connectivity)
    records: list[dict[str, Any]] = []
    foreground_area = 0
    kept_area = 0
    for label in range(1, count + 1):
        x = int(stats[label, cv2.CC_STAT_LEFT])
        y = int(stats[label, cv2.CC_STAT_TOP])
        width = int(stats[label, cv2.CC_STAT_WIDTH])
        height = int(stats[label, cv2.CC_STAT_HEIGHT])
        area = int(stats[label, cv2.CC_STAT_AREA])
        kept = area >= min_area
        foreground_area += area
        if kept:
            kept_area += area
        records.append({
            "label": label,
            "area": area,
            "x": x,
            "y": y,
            "width": width,
            "height": height,
            "cx": round(float(centroids[label][0]), 3),
            "cy": round(float(centroids[label][1]), 3),
            "kept": "true" if kept else "false",
        })
    mask_area = int(cv2.countNonZero(mask))
    if foreground_area != mask_area:
        raise RuntimeError(
            f"inconsistência de área: soma dos componentes={foreground_area}, pixels brancos={mask_area}"
        )
    summary = {
        "connectivity": connectivity,
        "count_raw": count,
        "count_filtered": sum(1 for record in records if record["kept"] == "true"),
        "area_total_px": foreground_area,
        "area_kept_px": kept_area,
        "foreground_pixels": mask_area,
        "area_conservation_ok": foreground_area == mask_area,
    }
    return records, summary


def _save_csv(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=("label", "area", "x", "y", "width", "height", "cx", "cy", "kept"))
        writer.writeheader()
        writer.writerows(records)


def _kernel(shape: str, size: int) -> np.ndarray:
    shape_code = {"ellipse": cv2.MORPH_ELLIPSE, "rect": cv2.MORPH_RECT, "cross": cv2.MORPH_CROSS}[shape]
    return cv2.getStructuringElement(shape_code, (size, size))


def _write_image(path: Path, image: np.ndarray) -> None:
    if not cv2.imwrite(str(path), image):
        raise OSError(f"não foi possível salvar a imagem: {path}")


def _labels_visualization(mask: np.ndarray, connectivity: int, min_area: int) -> tuple[np.ndarray, list[dict[str, Any]], dict[str, Any]]:
    records, summary = _component_records(mask, connectivity, min_area)
    _, labels, stats, _ = _connected_components(mask, connectivity)
    colored = np.zeros((*mask.shape, 3), dtype=np.uint8)
    for label in range(1, int(labels.max()) + 1):
        hue = int((label * 37) % 180)
        color_hsv = np.uint8([[[hue, 210, 255]]])
        color = tuple(int(v) for v in cv2.cvtColor(color_hsv, cv2.COLOR_HSV2BGR)[0, 0])
        colored[labels == label] = color
    for record in records:
        if record["kept"] != "true":
            continue
        x, y = int(record["x"]), int(record["y"])
        width, height = int(record["width"]), int(record["height"])
        cv2.rectangle(colored, (x, y), (x + width - 1, y + height - 1), (255, 255, 255), 2)
        cv2.putText(
            colored, str(record["label"]), (x, max(15, y - 4)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA,
        )
    return colored, records, summary


def _stage_overview(initial: np.ndarray, opened: np.ndarray, closed: np.ndarray, labels: np.ndarray) -> np.ndarray:
    panel_width = 600
    panel_height = 410
    header_height = 42
    gap = 16
    canvas = np.full((2 * (panel_height + header_height) + 3 * gap, 2 * panel_width + 3 * gap, 3), 246, dtype=np.uint8)
    panels = [("Mascara inicial", initial), ("Abertura", opened), ("Fechamento / final", closed), ("Rotulos e caixas", labels)]
    for idx, (title, image) in enumerate(panels):
        row, col = divmod(idx, 2)
        x0 = gap + col * (panel_width + gap)
        y0 = gap + row * (panel_height + header_height + gap)
        cv2.rectangle(canvas, (x0, y0), (x0 + panel_width, y0 + header_height - 1), (225, 232, 240), -1)
        cv2.putText(canvas, title, (x0 + 14, y0 + 28), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (25, 40, 58), 2, cv2.LINE_AA)
        if image.ndim == 2:
            image_bgr = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        else:
            image_bgr = image
        scale = min(panel_width / image_bgr.shape[1], panel_height / image_bgr.shape[0])
        width = max(1, int(image_bgr.shape[1] * scale))
        height = max(1, int(image_bgr.shape[0] * scale))
        resized = cv2.resize(image_bgr, (width, height), interpolation=cv2.INTER_NEAREST)
        canvas[y0 + header_height:y0 + header_height + height, x0:x0 + width] = resized
    return canvas


def run_segment(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    output_path = Path(args.output)
    image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
    if image is None:
        raise OSError(f"não foi possível ler a imagem: {input_path}")
    if output_path.suffix.lower() not in {".png", ".tif", ".tiff", ".bmp"}:
        raise ValueError("a máscara deve ser salva em formato sem perdas: .png, .tif, .tiff ou .bmp")

    mask = segment_image(image, args)
    if mask.ndim != 2 or mask.shape != image.shape[:2]:
        raise RuntimeError("erro interno: dimensões/canais da máscara não correspondem à imagem")
    values = set(int(value) for value in np.unique(mask))
    if not values.issubset({0, 255}):
        raise RuntimeError(f"erro interno: máscara não binária: {sorted(values)}")

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise OSError(f"não foi possível preparar o diretório de saída '{output_path.parent}': {exc}") from exc
    _write_image(output_path, mask)
    total = int(mask.size)
    foreground = int(cv2.countNonZero(mask))
    percentage = 100.0 * foreground / total if total else 0.0
    print(f"operation=segment method={args.method}")
    print(f"input={input_path} output={output_path}")
    print(f"width={image.shape[1]} height={image.shape[0]} channels=1")
    print(f"foreground_pixels={foreground} total_pixels={total} foreground_percent={percentage:.4f}")
    print(f"unique_values={sorted(values)} binary_validation=OK")
    return 0


def run_analyze(args: argparse.Namespace) -> int:
    input_path = Path(args.input)
    prefix = Path(args.output)
    initial = _read_mask(input_path)
    try:
        prefix.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise OSError(f"não foi possível preparar o diretório de saída '{prefix.parent}': {exc}") from exc

    open_kernel = _kernel(args.open_shape, args.open_kernel)
    close_kernel = _kernel(args.close_shape, args.close_kernel)
    opened = cv2.morphologyEx(initial, cv2.MORPH_OPEN, open_kernel, iterations=args.open_iterations)
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, close_kernel, iterations=args.close_iterations)

    initial_csv_records, initial_selected = _component_records(initial, args.connectivity, args.min_area)
    final_labels, final_csv_records, final_selected = _labels_visualization(closed, args.connectivity, args.min_area)
    initial_4 = _component_records(initial, 4, args.min_area)[1]
    initial_8 = _component_records(initial, 8, args.min_area)[1]
    opened_4 = _component_records(opened, 4, args.min_area)[1]
    opened_8 = _component_records(opened, 8, args.min_area)[1]
    final_4 = _component_records(closed, 4, args.min_area)[1]
    final_8 = _component_records(closed, 8, args.min_area)[1]

    outputs = {
        "initial_png": Path(f"{prefix}_initial.png"),
        "open_png": Path(f"{prefix}_open.png"),
        "close_png": Path(f"{prefix}_close.png"),
        "final_png": Path(f"{prefix}_final.png"),
        "initial_csv": Path(f"{prefix}_initial.csv"),
        "final_csv": Path(f"{prefix}_final.csv"),
        "labels_png": Path(f"{prefix}_labels.png"),
        "stages_png": Path(f"{prefix}_stages.png"),
        "summary_json": Path(f"{prefix}_summary.json"),
    }
    for path in outputs.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    _write_image(outputs["initial_png"], initial)
    _write_image(outputs["open_png"], opened)
    _write_image(outputs["close_png"], closed)
    _write_image(outputs["final_png"], closed)
    _write_image(outputs["labels_png"], final_labels)
    _write_image(outputs["stages_png"], _stage_overview(initial, opened, closed, final_labels))
    _save_csv(outputs["initial_csv"], initial_csv_records)
    _save_csv(outputs["final_csv"], final_csv_records)

    total_pixels = int(initial.size)
    morphology = [
        {"stage": "open", "operation": "opening", "shape": args.open_shape,
         "kernel_size": args.open_kernel, "iterations": args.open_iterations},
        {"stage": "close", "operation": "closing", "shape": args.close_shape,
         "kernel_size": args.close_kernel, "iterations": args.close_iterations},
    ]
    summary = {
        "input": str(input_path),
        "output_prefix": str(prefix),
        "image": {"width": int(initial.shape[1]), "height": int(initial.shape[0]), "channels": 1,
                  "total_pixels": total_pixels, "binary_values": [0, 255]},
        "connectivity_selected": args.connectivity,
        "min_area_px": args.min_area,
        "morphology_sequence": morphology,
        "stages": {
            "initial": {"connectivity_4": initial_4, "connectivity_8": initial_8, "selected_connectivity": initial_selected},
            "open": {"connectivity_4": opened_4, "connectivity_8": opened_8},
            "final": {"connectivity_4": final_4, "connectivity_8": final_8, "selected_connectivity": final_selected},
        },
        "outputs": {key: str(path) for key, path in outputs.items()},
    }
    outputs["summary_json"].write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print("operation=analyze")
    print(f"input={input_path} prefix={prefix}")
    print(f"dimensions={initial.shape[1]}x{initial.shape[0]} channels=1 connectivity={args.connectivity} min_area={args.min_area}")
    print("stage,connectivity,count_raw,count_filtered,foreground_pixels,area_kept_px")
    for stage_key, stage_name in (("initial", "initial"), ("open", "open"), ("final", "final")):
        stage = summary["stages"][stage_key]
        for conn in (4, 8):
            stats = stage[f"connectivity_{conn}"]
            print(f"{stage_name},{conn},{stats['count_raw']},{stats['count_filtered']},{stats['foreground_pixels']},{stats['area_kept_px']}")
    print(f"foreground_initial={cv2.countNonZero(initial)} foreground_final={cv2.countNonZero(closed)}")
    print("area_conservation=OK binary_validation=OK")
    for key, path in outputs.items():
        print(f"{key}={path}")
    return 0


def run(args: argparse.Namespace) -> int:
    validate_args(args)
    if args.operation == "segment":
        return run_segment(args)
    return run_analyze(args)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    argument_list = list(sys.argv[1:] if argv is None else argv)
    args = parser.parse_args(argument_list)
    try:
        _apply_config(args, parser, argument_list)
        validate_args(args)
        if args.operation == "segment":
            return run_segment(args)
        return run_analyze(args)
    except (OSError, ValueError, cv2.error) as exc:
        print(f"erro: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
