# Mini relatório — Laboratório M2.1: máscara binária e segmentação

## 1. Alvo e imagens

O alvo é **maçã verde inteira**. O objetivo da máscara é marcar os pixels que pertencem visualmente às maçãs, deixando o fundo em zero, como etapa inicial para a futura contagem de objetos no M2.2.

Foram utilizadas duas imagens com mais de um objeto discernível:

- **Imagem A — favorável (`images/input/macas_favoravel.png`):** três maçãs verdes sobre fundo cinza relativamente uniforme, com iluminação suave.
- **Imagem B — desafiadora (`images/input/macas_desafio.png`):** cinco maçãs verdes em uma mesa escura de madeira, com sombras, reflexos, folhas e outros elementos texturizados. A presença de folhas verdes dificulta uma segmentação que depende somente da cor.

Os arquivos de entrada em `images/input/` foram mantidos sem alterações durante os experimentos.

## 2. Métodos, pré-processamento e parâmetros

As duas configurações foram executadas sobre as mesmas imagens, sem filtro, recorte, redimensionamento ou alteração de cor antes da segmentação (`--blur 0`, padrão). A única diferença foi o método e seus parâmetros próprios.

| Configuração | Método | Parâmetros | Interpretação |
|---|---|---|---|
| A | Limiar fixo em cinza | `--threshold 140 --invert` | Converte para escala de cinza e aplica limiar global invertido. Pixels com valor menor ou igual a 140 tornam-se 255; os demais tornam-se 0. |
| B | Intervalo HSV | `--hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255` | Seleciona pixels verdes com matiz, saturação e brilho dentro dos limites. Valores HSV seguem as escalas do OpenCV (H: 0–179; S/V: 0–255). |

A inversão foi aplicada **somente** à configuração fixa porque a intenção era testar regiões mais escuras que o limiar na imagem em tons de cinza. Isso ajuda em trechos escuros das maçãs da imagem A, mas também classifica madeira, sombras e outros pixels escuros como primeiro plano na imagem B. O método HSV não usa `--invert`: o intervalo foi definido diretamente para a cor verde.

## 3. Resultados visuais

**Figura 1 — Imagem A (favorável): original, máscara fixa invertida e máscara HSV.** A máscara fixa é fragmentada pela variação de brilho dentro das maçãs e inclui partes sombreadas do fundo. A máscara HSV recupera silhuetas mais completas, mas perde alguns detalhes pouco saturados, como pontos de brilho e regiões próximas dos cabos.

![Imagem A: original, máscara fixed e máscara HSV](docs/macas_favoravel_comparacao.png)

**Figura 2 — Imagem B (desafiadora): original, máscara fixa invertida e máscara HSV.** O limiar fixo marca uma grande parte da mesa e das sombras como primeiro plano. HSV mantém as maçãs bem mais discerníveis, mas inclui pixels de folhas verdes fora dos frutos e deixa pequenas falhas em reflexos ou áreas menos saturadas.

![Imagem B: original, máscara fixed e máscara HSV](docs/macas_desafio_comparacao.png)

**Figura 3 — Sobreposição na imagem B.** A máscara aparece em vermelho sobre a imagem original. A sobreposição permite localizar falsos positivos (vermelho fora das maçãs) e falsos negativos (partes do fruto sem vermelho).

![Imagem B: sobreposição fixed e HSV](docs/macas_desafio_sobreposicao.png)

As figuras mostram inspeção visual, não uma comparação com uma máscara de referência anotada. Portanto, as medidas abaixo são proporções de pixels classificados como primeiro plano, e não métricas de acurácia.

## 4. Quantificação e validação

A proporção de primeiro plano foi calculada como `pixels com valor 255 / total de pixels × 100`.

| Imagem | Configuração | Pixels de primeiro plano | Total de pixels | Proporção de primeiro plano |
|---|---|---:|---:|---:|
| A — favorável | Fixed, limiar 140, invertido | 573.842 | 1.572.528 | 36,49% |
| A — favorável | HSV, H 25–85, S 70–255, V 35–255 | 455.092 | 1.572.528 | 28,94% |
| B — desafiadora | Fixed, limiar 140, invertido | 1.302.750 | 1.572.864 | 82,83% |
| B — desafiadora | HSV, H 25–85, S 70–255, V 35–255 | 635.087 | 1.572.864 | 40,38% |

A queda da proporção da configuração HSV na imagem B, comparada ao limiar fixo invertido, indica que menos pixels escuros do fundo foram classificados como objeto. A proporção de HSV na imagem B ainda é elevada em parte pela folhagem e por outros tons verdes. **A proporção sozinha não prova que a máscara é mais correta**; essa interpretação depende da inspeção visual.

A validação programática foi feita pelo próprio programa e pelos testes:

- largura e altura da máscara iguais às da entrada;
- máscara 2D (um canal);
- conjunto de valores limitado a `{0, 255}`;
- saída em PNG sem perdas;
- contagem e proporção de primeiro plano impressas no terminal.

## 5. Discussão

### (a) Em que casos o limiar fixo falhou ou funcionou?

Na imagem A, o limiar fixo invertido recupera regiões escuras das maçãs, mas não acompanha os reflexos nem a variação interna de brilho; por isso, a máscara fica fragmentada. Na imagem B, falha de forma evidente: como grande parte da mesa de madeira e das sombras tem intensidade em cinza inferior a 140, elas viram primeiro plano e se conectam visualmente às maçãs. O resultado não separa cada fruto de maneira confiável.

### (b) Qual parâmetro foi mais sensível?

O limiar `--threshold` foi o mais sensível na configuração fixa. Mantendo os outros fatores constantes e variando o limiar invertido de 120 para 180, a proporção de primeiro plano na imagem A aumentou de **19,69% para 71,46%**; na imagem B aumentou de **78,01% para 89,60%**. Isso mostra que pequenas mudanças na fronteira de intensidade podem mudar substancialmente quanto do fundo é considerado objeto.

Na configuração HSV, a faixa de saturação também influencia o resultado, mas uma variação exploratória de `--smin` de 50 para 130 alterou a proporção de 30,17% para 25,71% na imagem A e de 41,04% para 36,25% na imagem B. Nesse conjunto, o limiar fixo apresentou a maior variação proporcional para o parâmetro testado.

### (c) Quais erros podem atrapalhar a contagem de objetos no M2.2?

- **Falsos positivos:** folhas verdes e regiões de fundo classificadas como verdes podem virar componentes extras e inflar a contagem.
- **Falsos negativos:** brilhos especulares, pontos com pouca saturação e partes sombreadas ou com cor fora do intervalo podem abrir buracos, dividir uma maçã em várias regiões ou apagar uma maçã pequena.
- **Objetos encostados:** se duas maçãs ou uma maçã e uma folha forem conectadas na máscara, o algoritmo de componentes conectados pode contá-las como um objeto só.
- **Ruído e fragmentação:** pequenas regiões isoladas podem ser contadas como objetos; buracos e bordas fragmentadas podem alterar a área e a forma dos componentes.

## 6. Configuração selecionada para M2.2

A configuração escolhida como ponto de partida é **HSV** (`H=25–85`, `S=70–255`, `V=35–255`). A classe foi definida por sua cor verde, de modo que HSV oferece um critério mais relacionado ao alvo do que a intensidade global em tons de cinza. Nas duas imagens, as maçãs permanecem discerníveis e o método é menos vulnerável ao fundo escuro da cena B.

A seleção não elimina falsos positivos nas folhas nem falsos negativos nos reflexos. Na próxima etapa, a contagem de componentes conectados deverá ser acompanhada de inspeção visual e, se necessário, refinamento dos limites HSV ou operações morfológicas. Esses refinamentos não foram aplicados neste marco para manter explícita a comparação básica entre os dois métodos.

## 7. Como reproduzir

Na raiz do projeto, execute os quatro comandos documentados no `README.md`. Para testar os casos mínimos:

```bash
python -m unittest discover -s tests -v
```

O teste sintético usa pixels `99`, `100` e `101` com `--threshold 100` e confirma que o limiar fixo normal produz `[0, 0, 255]`, incluindo o caso exatamente no limiar.

---

# M2.2 — Componentes conexos e sequência morfológica

## 8. Objetivo e máscara de entrada

A análise parte das máscaras HSV produzidas pela operação `segment` deste projeto. Os pixels de primeiro plano são representados por `255` (branco) e o fundo por `0` (preto). As máscaras iniciais foram preservadas antes de aplicar qualquer operação morfológica.

Foram processadas duas cenas com comportamentos diferentes:

- **Cena favorável:** três maçãs verdes diante de um fundo neutro. As regiões das frutas ficam próximas e algumas partes da máscara formam pontes estreitas, portanto nem sempre correspondem a três componentes independentes.
- **Cena desafiadora:** cinco maçãs verdes sobre madeira, com folhas, sombras e reflexos. Variações de cor e textura resultam em regiões fragmentadas e falsos positivos fora das frutas.

## 9. Conectividade 4 e 8

A conectividade foi calculada sobre a mesma máscara inicial, sem alterar os pixels. Na conectividade **4**, cada pixel se conecta apenas aos vizinhos horizontais e verticais; na conectividade **8**, os quatro vizinhos diagonais também são considerados. Por isso, duas regiões que se tocam somente pelos cantos podem ser contadas como dois componentes em 4-conectada e um em 8-conectada.

![Exemplo sintético das conectividades 4 e 8](docs/m2_2_conectividade_diagonal.png)

| Cena | Componentes iniciais — conexão 4 | Componentes iniciais — conexão 8 |
|---|---:|---:|
| Favorável | 143 | 97 |
| Desafiadora | 572 | 279 |

A diferença entre as contagens é especialmente evidente na cena desafiadora. Muitos pixels de ruído e regiões irregulares se tocam diagonalmente; a conectividade 8 reúne parte dessas regiões, reduzindo a contagem em relação à conectividade 4. A análise final e os CSVs usam conectividade **8**, documentada em `lab.json`; o resumo JSON também registra as contagens das duas conectividades para comparação.

## 10. Sequência morfológica

A sequência aplicada foi:

1. **Abertura:** elemento estruturante elíptico de `5×5`, uma iteração. A operação remove partículas pequenas, pontos isolados e saliências mais estreitas que o elemento estruturante.
2. **Fechamento:** elemento estruturante elíptico de `7×7`, uma iteração. A operação preenche furos pequenos e fecha lacunas estreitas entre pixels brancos que ficaram separados.

A ordem foi escolhida para reduzir primeiro os detalhes isolados e depois recuperar pequenos furos e interrupções que restam na máscara. A abertura não garante que todo ruído seja removido, e o fechamento pode unir regiões próximas que deveriam continuar separadas. Os parâmetros são mantidos em `lab.json` e podem ser substituídos por argumentos na linha de comando.

### Cena favorável

![Estágios morfológicos da cena favorável](docs/m2_2_macas_favoravel_pipeline.png)

| Etapa | Componentes brutos (4) | Componentes brutos (8) | Pixels de primeiro plano |
|---|---:|---:|---:|
| Máscara inicial | 143 | 97 | 455.092 |
| Após abertura | 11 | 11 | 453.204 |
| Após fechamento — final | 9 | 6 | 454.762 |

A abertura reduziu em 1.888 o número de pixels brancos da máscara inicial; o fechamento recuperou 1.558 pixels, deixando a área final 330 pixels abaixo da área inicial. Na conectividade 8, a contagem passou de 97 para 11 após a abertura e para 6 após o fechamento. Embora a sequência remova diversas regiões pequenas, ela não separa as maçãs que já estavam conectadas na segmentação; o maior componente continua reunindo uma área muito grande. Esse caso mostra que reduzir o número de componentes não significa necessariamente aproximar a contagem do número visual de frutas.

### Cena desafiadora

![Estágios morfológicos da cena desafiadora](docs/m2_2_macas_desafio_pipeline.png)

| Etapa | Componentes brutos (4) | Componentes brutos (8) | Pixels de primeiro plano |
|---|---:|---:|---:|
| Máscara inicial | 572 | 279 | 635.087 |
| Após abertura | 72 | 68 | 626.056 |
| Após fechamento — final | 37 | 36 | 631.829 |

A abertura removeu 9.031 pixels brancos, cerca de 1,42% da área inicial, e reduziu a contagem de 279 para 68 componentes na conectividade 8. O fechamento recuperou 5.773 pixels e reduziu a contagem para 36. As regiões pequenas foram reduzidas, mas ainda restam vários componentes associados a folhas, textura da madeira e fragmentos da máscara das maçãs. O fechamento aproxima partes interrompidas; quando a lacuna separa objetos diferentes, a mesma operação pode uni-los.

## 11. Comparação antes e depois e filtro por área

O filtro adotado foi **área maior ou igual a 1.000 pixels** (`--min-area 1000`). O critério é aplicado de forma idêntica à máscara inicial e à máscara final. Ele identifica quais linhas são mantidas no CSV e quais caixas são desenhadas em `labels.png`; não altera a máscara nem a contagem bruta. A coluna `kept` registra o resultado do filtro em cada componente.

| Cena | Etapa | Componentes brutos (8) | Componentes mantidos (área ≥ 1.000) | Área total branca (px) | Área dos componentes mantidos (px) |
|---|---|---:|---:|---:|---:|
| Favorável | Inicial | 97 | 1 | 455.092 | 454.551 |
| Favorável | Final | 6 | 2 | 454.762 | 454.617 |
| Desafiadora | Inicial | 279 | 11 | 635.087 | 628.045 |
| Desafiadora | Final | 36 | 9 | 631.829 | 625.676 |

Em todos os estágios, a soma das áreas dos componentes brutos coincide com a quantidade de pixels brancos da respectiva máscara. Essa conservação de área é verificada pelo programa e armazenada em `*_summary.json`. A área após o filtro é apresentada separadamente porque exclui componentes abaixo do limite, sem modificar a imagem binária.

Dois efeitos importantes aparecem nos resultados:

- **Redução de fragmentos:** na cena desafiadora, a abertura reduz os componentes brutos em conectividade 8 de 279 para 68; após o fechamento, são 36. Isso simplifica a lista de regiões pequenas, embora não elimine todos os falsos positivos.
- **Risco de fusão ou fragmentação:** na cena favorável, os componentes grandes mudam de um para dois após a sequência, mesmo que visualmente existam três maçãs. A forma como as pontes finas e os detalhes são removidos ou preservados altera a rotulação; a quantidade de componentes não representa necessariamente a quantidade real de objetos.

## 12. Arquivos e reprodutibilidade

Para cada cena foram registrados a cópia da máscara inicial (`*_initial.png`), a máscara após abertura (`*_open.png`), a máscara após fechamento (`*_close.png`), a máscara final (`*_final.png`), o CSV inicial (`*_initial.csv`), o CSV final (`*_final.csv`), a visualização colorida (`*_labels.png`), o painel de etapas (`*_stages.png`) e o resumo (`*_summary.json`), todos em `results/m2_2/`.

Cada CSV exclui o rótulo de fundo e contém rótulo, área, caixa delimitadora, centroide e resultado do filtro. A caixa delimitadora usa `x`, `y`, `width` e `height`; o centroide utiliza coordenadas `cx` e `cy`. Os rótulos são identificadores locais de cada máscara e não precisam manter o mesmo número entre estágios.

Comando usado para reproduzir a análise das duas máscaras:

```bash
python pdi_lab.py --input images/output/macas_favoravel_mask.png --output results/m2_2/macas_favoravel --operation analyze --config lab.json
python pdi_lab.py --input images/output/macas_desafio_mask.png --output results/m2_2/macas_desafio --operation analyze --config lab.json
```

## 13. Limitações e conclusão

A sequência morfológica diminui ruído isolado e pode fechar pequenas falhas, mas não recupera informação que não existe na máscara inicial. Se duas frutas estiverem unidas por uma região branca, o fechamento pode manter ou reforçar a união; se a segmentação deixar partes da fruta ausentes, a abertura pode remover fragmentos que seriam úteis para a análise. Folhas e madeira classificados como primeiro plano continuam sujeitos à rotulação como componentes extras.

A contagem final não equivale automaticamente ao número real de objetos: ela representa regiões conectadas na máscara binária sob uma conectividade específica. Contato entre objetos, falsos positivos, falsos negativos, sombras, fragmentação e o critério de área influenciam o resultado. Na cena favorável, a rotulação final não reproduz as três maçãs visíveis como três componentes; na cena desafiadora, a lista continua incluindo regiões que não representam maçãs completas. A interpretação dos rótulos deve, portanto, considerar as imagens originais e os estágios intermediários, e não apenas um número de contagem.

## 14. Testes M2.2

A suíte automatizada inclui as duas cenas reais do conjunto de estudo e máscaras sintéticas para testar conectividade 4/8 em pixels diagonais, remoção de ruído isolado por abertura, fechamento de um furo pequeno, máscara vazia e componente que toca a borda. Também verifica a falha para conectividade e área mínima inválidas, a criação dos arquivos intermediários/CSV/JSON e a igualdade entre a soma das áreas dos componentes brutos e os pixels de primeiro plano.
