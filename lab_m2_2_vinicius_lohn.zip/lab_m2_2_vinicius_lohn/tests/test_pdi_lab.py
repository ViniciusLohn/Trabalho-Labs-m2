from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "pdi_lab.py"
IMAGES = ROOT / "images" / "input"
MASKS = ROOT / "images" / "output"


class PdiLabCliTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )

    @staticmethod
    def segment_args(input_path: Path, output_path: Path, method: str, *extra: str) -> list[str]:
        return [
            "--input", str(input_path), "--output", str(output_path),
            "--operation", "segment", "--method", method, *extra,
        ]

    @staticmethod
    def analyze_args(input_path: Path, prefix: Path, *extra: str) -> list[str]:
        return ["--input", str(input_path), "--output", str(prefix), "--operation", "analyze", *extra]

    def test_fixed_synthetic_threshold_includes_below_equal_above(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "limiar.png"
            output = tmp / "mascara.png"
            values = np.array([[99, 100, 101]], dtype=np.uint8)
            self.assertTrue(cv2.imwrite(str(source), values))
            result = self.run_cli(*self.segment_args(source, output, "fixed", "--threshold", "100"))
            self.assertEqual(result.returncode, 0, result.stderr)
            mask = cv2.imread(str(output), cv2.IMREAD_UNCHANGED)
            self.assertIsNotNone(mask)
            self.assertEqual(mask.ndim, 2)
            self.assertEqual(mask.tolist(), [[0, 0, 255]])

    def test_two_input_images_segment_fixed_and_hsv_masks_are_binary(self) -> None:
        for stem in ("macas_favoravel", "macas_desafio"):
            source = IMAGES / f"{stem}.png"
            original = cv2.imread(str(source), cv2.IMREAD_COLOR)
            self.assertIsNotNone(original, f"imagem não encontrada: {source}")
            configs = {
                "fixed": ["--threshold", "140", "--invert"],
                "hsv": ["--hmin", "25", "--hmax", "85", "--smin", "70", "--smax", "255", "--vmin", "35", "--vmax", "255"],
            }
            for method, extra in configs.items():
                with self.subTest(image=stem, method=method), tempfile.TemporaryDirectory() as td:
                    output = Path(td) / f"{stem}_{method}.png"
                    result = self.run_cli(*self.segment_args(source, output, method, *extra))
                    self.assertEqual(result.returncode, 0, result.stderr)
                    mask = cv2.imread(str(output), cv2.IMREAD_UNCHANGED)
                    self.assertIsNotNone(mask)
                    self.assertEqual(mask.shape, original.shape[:2])
                    self.assertEqual(mask.ndim, 2)
                    self.assertTrue(set(np.unique(mask).tolist()).issubset({0, 255}))
                    self.assertIn("binary_validation=OK", result.stdout)

    def test_diagonal_pixels_have_different_4_and_8_connectivity_counts(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "diagonal.png"
            prefix = tmp / "diagonal"
            mask = np.zeros((8, 8), dtype=np.uint8)
            mask[2, 2] = 255
            mask[3, 3] = 255
            self.assertTrue(cv2.imwrite(str(source), mask))
            result = self.run_cli(*self.analyze_args(source, prefix, "--min-area", "0"))
            self.assertEqual(result.returncode, 0, result.stderr)
            summary = json.loads(Path(f"{prefix}_summary.json").read_text(encoding="utf-8"))
            self.assertEqual(summary["stages"]["initial"]["connectivity_4"]["count_raw"], 2)
            self.assertEqual(summary["stages"]["initial"]["connectivity_8"]["count_raw"], 1)

    def test_opening_removes_isolated_noise_and_preserves_main_region(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "ruido.png"
            prefix = tmp / "ruido"
            mask = np.zeros((64, 64), dtype=np.uint8)
            mask[18:46, 18:46] = 255
            mask[5, 5] = 255
            self.assertTrue(cv2.imwrite(str(source), mask))
            result = self.run_cli(*self.analyze_args(
                source, prefix, "--min-area", "0", "--open-kernel", "3", "--close-kernel", "3"
            ))
            self.assertEqual(result.returncode, 0, result.stderr)
            opened = cv2.imread(f"{prefix}_open.png", cv2.IMREAD_UNCHANGED)
            self.assertEqual(int(opened[5, 5]), 0)
            self.assertEqual(int(opened[30, 30]), 255)
            self.assertLess(cv2.countNonZero(opened), cv2.countNonZero(mask))

    def test_closing_fills_small_hole_after_opening(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "furo.png"
            prefix = tmp / "furo"
            mask = np.zeros((60, 60), dtype=np.uint8)
            mask[8:52, 8:52] = 255
            mask[29, 29] = 0
            self.assertTrue(cv2.imwrite(str(source), mask))
            result = self.run_cli(*self.analyze_args(
                source, prefix, "--min-area", "0", "--open-kernel", "3", "--close-kernel", "7"
            ))
            self.assertEqual(result.returncode, 0, result.stderr)
            opened = cv2.imread(f"{prefix}_open.png", cv2.IMREAD_UNCHANGED)
            final = cv2.imread(f"{prefix}_final.png", cv2.IMREAD_UNCHANGED)
            self.assertEqual(int(opened[29, 29]), 0)
            self.assertEqual(int(final[29, 29]), 255)

    def test_empty_mask_has_zero_components(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "vazia.png"
            prefix = tmp / "vazia"
            self.assertTrue(cv2.imwrite(str(source), np.zeros((32, 32), dtype=np.uint8)))
            result = self.run_cli(*self.analyze_args(source, prefix, "--min-area", "0"))
            self.assertEqual(result.returncode, 0, result.stderr)
            summary = json.loads(Path(f"{prefix}_summary.json").read_text(encoding="utf-8"))
            self.assertEqual(summary["stages"]["initial"]["connectivity_8"]["count_raw"], 0)
            self.assertEqual(summary["stages"]["final"]["connectivity_8"]["count_raw"], 0)
            self.assertEqual(summary["stages"]["final"]["connectivity_8"]["foreground_pixels"], 0)

    def test_border_touching_component_is_exported_with_zero_origin(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "borda.png"
            prefix = tmp / "borda"
            mask = np.zeros((50, 50), dtype=np.uint8)
            mask[:20, :25] = 255
            self.assertTrue(cv2.imwrite(str(source), mask))
            result = self.run_cli(*self.analyze_args(source, prefix, "--min-area", "0"))
            self.assertEqual(result.returncode, 0, result.stderr)
            rows = (Path(f"{prefix}_initial.csv").read_text(encoding="utf-8").splitlines())
            self.assertIn(",x,y,width,height,", rows[0])
            self.assertRegex(rows[1], r",0,0,25,20,")

    def test_study_masks_produce_all_stages_csv_and_area_conservation(self) -> None:
        for stem in ("macas_favoravel", "macas_desafio"):
            source = MASKS / f"{stem}_mask.png"
            with self.subTest(image=stem), tempfile.TemporaryDirectory() as td:
                prefix = Path(td) / stem
                result = self.run_cli(*self.analyze_args(source, prefix, "--min-area", "1000"))
                self.assertEqual(result.returncode, 0, result.stderr)
                for suffix in (
                    "_initial.png", "_open.png", "_close.png", "_final.png",
                    "_initial.csv", "_final.csv", "_labels.png", "_stages.png", "_summary.json",
                ):
                    self.assertTrue(Path(f"{prefix}{suffix}").is_file(), suffix)
                summary = json.loads(Path(f"{prefix}_summary.json").read_text(encoding="utf-8"))
                for stage in ("initial", "open", "final"):
                    for conn in (4, 8):
                        stats = summary["stages"][stage][f"connectivity_{conn}"]
                        self.assertTrue(stats["area_conservation_ok"])
                        self.assertEqual(stats["area_total_px"], stats["foreground_pixels"])

    def test_failed_read_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.segment_args(Path(td) / "nao_existe.png", output, "fixed"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("não foi possível ler", result.stderr)

    def test_unknown_method_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.segment_args(IMAGES / "macas_favoravel.png", output, "not-a-method"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("invalid choice", result.stderr)

    def test_invalid_parameter_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.segment_args(IMAGES / "macas_favoravel.png", output, "fixed", "--threshold", "300"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("--threshold deve estar entre 0 e 255", result.stderr)

    def test_invalid_connectivity_and_min_area_return_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "mascara.png"
            self.assertTrue(cv2.imwrite(str(source), np.zeros((20, 20), dtype=np.uint8)))
            bad_conn = self.run_cli(*self.analyze_args(source, tmp / "c", "--connectivity", "6"))
            self.assertNotEqual(bad_conn.returncode, 0)
            bad_area = self.run_cli(*self.analyze_args(source, tmp / "a", "--min-area", "-1"))
            self.assertNotEqual(bad_area.returncode, 0)
            self.assertIn("--min-area deve ser um inteiro não negativo", bad_area.stderr)

    def test_non_binary_mask_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "mascara_nao_binaria.png"
            mask = np.zeros((12, 12), dtype=np.uint8)
            mask[3:8, 3:8] = 255
            mask[0, 0] = 127
            self.assertTrue(cv2.imwrite(str(source), mask))
            result = self.run_cli(*self.analyze_args(source, tmp / "saida", "--min-area", "0"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("somente 0 e 255", result.stderr)

    def test_output_write_failures_return_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            blocker = tmp / "not_a_directory"
            blocker.write_text("arquivo usado como diretório", encoding="utf-8")

            segment_result = self.run_cli(*self.segment_args(
                IMAGES / "macas_favoravel.png", blocker / "mask.png", "fixed"
            ))
            self.assertNotEqual(segment_result.returncode, 0)
            self.assertIn("não foi possível preparar o diretório de saída", segment_result.stderr)

            source_mask = tmp / "valid_mask.png"
            self.assertTrue(cv2.imwrite(str(source_mask), np.zeros((8, 8), dtype=np.uint8)))
            analyze_result = self.run_cli(*self.analyze_args(source_mask, blocker / "result", "--min-area", "0"))
            self.assertNotEqual(analyze_result.returncode, 0)
            self.assertIn("não foi possível preparar o diretório de saída", analyze_result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
