# PDI Lab — M2.2: componentes conexos e sequência morfológica

Projeto da entrega M2.2, em Python/OpenCV, para limpar máscaras binárias, rotular componentes conexos, contar regiões e exportar estatísticas. O código mantém a operação `segment` da M2.1 e acrescenta `analyze`, conforme o contrato técnico da disciplina.

## Requisitos

- Python 3.10 ou mais recente
- `numpy>=1.24`
- pacote de ligação OpenCV `opencv-python>=4.8` (testado com OpenCV 4.13.0 e NumPy 2.3.5)

Instalação das dependências:

```bash
python -m pip install -r requirements.txt
```

A forma comum de invocação, a partir da raiz do projeto, é `python -m pdi_lab`. Em Windows, use `py -m pdi_lab`; em Linux/macOS, use `python3 -m pdi_lab` quando `python` não apontar para Python 3. Também estão disponíveis os lançadores `./pdi_lab` (Linux/macOS) e `pdi_lab.bat` (Windows).

Confira as opções com:

```bash
python -m pdi_lab --help
```

## Estrutura do projeto

```text
lab_m2_2_vinicius_lohn/
├── pdi_lab.py
├── pdi_lab                 # lançador POSIX
├── pdi_lab.bat             # lançador Windows
├── requirements.txt
├── lab.json                # metadados da entrega M2.2 e parâmetros
├── README.md
├── REPORT.md               # relatório acumulado com seções M2.1 e M2.2
├── AI_USAGE.md
├── images/
│   ├── input/              # cenas de entrada sem processamento
│   └── output/             # máscaras da etapa M2.1
├── results/m2_2/           # saídas intermediárias, CSVs, rótulos e JSON
├── docs/                   # figuras para comparação visual
└── tests/
    └── test_pdi_lab.py
```

As cenas de entrada contêm três maçãs verdes em fundo neutro e cinco maçãs verdes sobre uma mesa de madeira, com sombras, reflexos e folhas. Os arquivos em `images/input/` não são sobrescritos pelo processamento.

## M2.1 — Segmentação

Formato de comando:

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/mask.png --operation segment --method fixed --threshold 120
```

`--output` é o caminho completo do arquivo de máscara. As máscaras devem ser gravadas em formato sem perdas (`.png`, `.tif`, `.tiff` ou `.bmp`); o programa valida dimensões, canal único e valores `{0, 255}`.

### Métodos e parâmetros

- `fixed`: limiar global em escala de cinza. `--threshold` é um inteiro de `0` a `255`. Sem `--invert`, valores acima do limiar ficam brancos; com `--invert`, valores menores ou iguais ao limiar ficam brancos.
- `otsu`: limiar global automático de Otsu. `--invert` controla a polaridade.
- `adaptive`: limiar adaptativo Gaussiano. `--block-size` deve ser ímpar e maior ou igual a `3`; `--c` é a constante subtraída da média local.
- `hsv`: intervalo de cor no HSV do OpenCV. `--hmin/--hmax` usam `0–179`; `--smin/--smax` e `--vmin/--vmax` usam `0–255`. Quando `--hmin > --hmax`, o intervalo de matiz é dividido nos trechos `[hmin,179]` e `[0,hmax]`.
- `--blur`: filtro Gaussiano opcional antes da segmentação. O valor `0` desativa o filtro; outros valores devem ser ímpares e maiores ou iguais a `3`.

### Comandos reproduzíveis da M2.1

Limiar fixo com inversão, `threshold=140`:

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/macas_favoravel_fixed.png --operation segment --method fixed --threshold 140 --invert
python -m pdi_lab --input images/input/macas_desafio.png --output images/output/macas_desafio_fixed.png --operation segment --method fixed --threshold 140 --invert
```

Seleção de verde em HSV (`H=25–85`, `S=70–255`, `V=35–255`), usada para gerar as máscaras de entrada da M2.2:

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/macas_favoravel_mask.png --operation segment --method hsv --hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255
python -m pdi_lab --input images/input/macas_desafio.png --output images/output/macas_desafio_mask.png --operation segment --method hsv --hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255
```

### Configuração HSV selecionada

A faixa HSV usa a cor verde como critério principal. Na segunda cena, folhas e outras áreas verdes ainda podem aparecer na máscara; reflexos e áreas pouco saturadas das maçãs podem ser omitidos. A máscara é uma estimativa binária da região de interesse, não uma classificação perfeita dos frutos.

## M2.2 — Componentes conexos e morfologia

Formato de comando:

```bash
python -m pdi_lab --input images/output/macas_favoravel_mask.png --output results/m2_2/macas_favoravel --operation analyze --connectivity 8 --min-area 1000
```

Para reproduzir a mesma máscara usando conectividade 4:

```bash
python -m pdi_lab --input images/output/macas_favoravel_mask.png --output results/m2_2/macas_favoravel_conn4 --operation analyze --connectivity 4 --min-area 1000
```

Para reproduzir a configuração documentada pelo arquivo `lab.json`:

```bash
python -m pdi_lab --input images/output/macas_favoravel_mask.png --output results/m2_2/macas_favoravel --operation analyze --config lab.json
python -m pdi_lab --input images/output/macas_desafio_mask.png --output results/m2_2/macas_desafio --operation analyze --config lab.json
```

Os parâmetros também podem ser informados diretamente, sem alterar o código:

```bash
python -m pdi_lab --input images/output/macas_desafio_mask.png --output results/m2_2/macas_desafio --operation analyze --connectivity 8 --min-area 1000 --open-shape ellipse --open-kernel 5 --open-iterations 1 --close-shape ellipse --close-kernel 7 --close-iterations 1
```

### Parâmetros da sequência

1. **Abertura:** elemento estruturante elíptico `5×5`, uma iteração. A erosão seguida de dilatação remove partículas pequenas e saliências estreitas.
2. **Fechamento:** elemento estruturante elíptico `7×7`, uma iteração. A dilatação seguida de erosão fecha furos pequenos e aproxima trechos separados por lacunas estreitas.

A ordem é abertura seguida de fechamento. A abertura reduz ruído isolado; o fechamento atua depois sobre falhas e lacunas remanescentes. O fechamento pode também conectar regiões vizinhas. Tamanho, forma e número de iterações são configuráveis pelos argumentos indicados acima ou pela seção `analyze` de `lab.json`.

### Arquivos gerados por `analyze`

Para um prefixo `results/m2_2/cena`, os arquivos têm estes nomes:

| Arquivo | Conteúdo |
|---|---|
| `cena_initial.png` | Cópia da máscara binária de entrada. |
| `cena_open.png` | Máscara após a abertura. |
| `cena_close.png` | Máscara após o fechamento. |
| `cena_final.png` | Cópia da máscara final após a sequência. |
| `cena_initial.csv` | Componentes da máscara inicial. |
| `cena_final.csv` | Componentes da máscara final. |
| `cena_labels.png` | Rótulos coloridos e caixas dos componentes mantidos pelo filtro. |
| `cena_stages.png` | Painel com máscara inicial, estágios e rótulos. |
| `cena_summary.json` | Parâmetros, contagens, áreas e caminhos das saídas. |

Os CSVs contêm `label,area,x,y,width,height,cx,cy,kept`. A área mínima padrão é `1000` pixels e a regra é `area >= min-area`. O filtro identifica quais componentes entram na contagem filtrada e na visualização; ele não apaga pixels das máscaras. A soma das áreas dos componentes brutos deve ser igual à contagem de pixels brancos da máscara correspondente.

`--connectivity` aceita `4` ou `8` e controla a conectividade usada nos CSVs e na visualização. O resumo JSON inclui contagens e áreas para ambas as conectividades nas máscaras inicial, após abertura e final. O rótulo de fundo (`0`) não é exportado como objeto.

## Testes

Execute na raiz:

```bash
python -m unittest discover -s tests -v
```

Os testes cobrem o limiar fixo com pixels abaixo, no e acima do limiar; as duas máscaras reais sob os métodos fixo e HSV; pixels diagonais com conectividades 4 e 8; remoção de ruído por abertura; fechamento de furo pequeno; máscara vazia; objeto encostado na borda; rejeição de máscara não binária; arquivos e conservação de área nas duas cenas; e falhas de leitura, gravação e parâmetros.

O programa retorna `0` em caso de sucesso e código diferente de `0` em caso de falha.
