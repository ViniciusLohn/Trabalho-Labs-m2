# Registro de uso de ferramentas de IA


utilizei a ferramenta de IA chatgpt como apoio à estruturação e revisão do código.