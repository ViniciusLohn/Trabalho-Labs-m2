# Mini relatório — Laboratório M2.1: máscara binária e segmentação

## 1. Alvo e imagens

O alvo é **maçã verde inteira**. O objetivo da máscara é marcar os pixels que pertencem visualmente às maçãs, deixando o fundo em zero, como etapa inicial para a futura contagem de objetos no M2.2.

Foram utilizadas duas imagens com mais de um objeto discernível:

- **Imagem A — favorável (`images/input/macas_favoravel.png`):** três maçãs verdes sobre fundo cinza relativamente uniforme, com iluminação suave.
- **Imagem B — desafiadora (`images/input/macas_desafio.png`):** cinco maçãs verdes em uma mesa escura de madeira, com sombras, reflexos, folhas e outros elementos texturizados. A presença de folhas verdes dificulta uma segmentação que depende somente da cor.

Os arquivos de entrada em `images/input/` foram mantidos sem alterações durante os experimentos.

## 2. Métodos, pré-processamento e parâmetros

As duas configurações foram executadas sobre as mesmas imagens, sem filtro, recorte, redimensionamento ou alteração de cor antes da segmentação (`--blur 0`, padrão). A única diferença foi o método e seus parâmetros próprios.

| Configuração | Método | Parâmetros | Interpretação |
|---|---|---|---|
| A | Limiar fixo em cinza | `--threshold 140 --invert` | Converte para escala de cinza e aplica limiar global invertido. Pixels com valor menor ou igual a 140 tornam-se 255; os demais tornam-se 0. |
| B | Intervalo HSV | `--hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255` | Seleciona pixels verdes com matiz, saturação e brilho dentro dos limites. Valores HSV seguem as escalas do OpenCV (H: 0–179; S/V: 0–255). |

A inversão foi aplicada **somente** à configuração fixa porque a intenção era testar regiões mais escuras que o limiar na imagem em tons de cinza. Isso ajuda em trechos escuros das maçãs da imagem A, mas também classifica madeira, sombras e outros pixels escuros como primeiro plano na imagem B. O método HSV não usa `--invert`: o intervalo foi definido diretamente para a cor verde.

## 3. Resultados visuais

**Figura 1 — Imagem A (favorável): original, máscara fixa invertida e máscara HSV.** A máscara fixa é fragmentada pela variação de brilho dentro das maçãs e inclui partes sombreadas do fundo. A máscara HSV recupera silhuetas mais completas, mas perde alguns detalhes pouco saturados, como pontos de brilho e regiões próximas dos cabos.

![Imagem A: original, máscara fixed e máscara HSV](docs/macas_favoravel_comparacao.png)

**Figura 2 — Imagem B (desafiadora): original, máscara fixa invertida e máscara HSV.** O limiar fixo marca uma grande parte da mesa e das sombras como primeiro plano. HSV mantém as maçãs bem mais discerníveis, mas inclui pixels de folhas verdes fora dos frutos e deixa pequenas falhas em reflexos ou áreas menos saturadas.

![Imagem B: original, máscara fixed e máscara HSV](docs/macas_desafio_comparacao.png)

**Figura 3 — Sobreposição na imagem B.** A máscara aparece em vermelho sobre a imagem original. A sobreposição permite localizar falsos positivos (vermelho fora das maçãs) e falsos negativos (partes do fruto sem vermelho).

![Imagem B: sobreposição fixed e HSV](docs/macas_desafio_sobreposicao.png)

As figuras mostram inspeção visual, não uma comparação com uma máscara de referência anotada. Portanto, as medidas abaixo são proporções de pixels classificados como primeiro plano, e não métricas de acurácia.

## 4. Quantificação e validação

A proporção de primeiro plano foi calculada como `pixels com valor 255 / total de pixels × 100`.

| Imagem | Configuração | Pixels de primeiro plano | Total de pixels | Proporção de primeiro plano |
|---|---|---:|---:|---:|
| A — favorável | Fixed, limiar 140, invertido | 573.842 | 1.572.528 | 36,49% |
| A — favorável | HSV, H 25–85, S 70–255, V 35–255 | 455.092 | 1.572.528 | 28,94% |
| B — desafiadora | Fixed, limiar 140, invertido | 1.302.750 | 1.572.864 | 82,83% |
| B — desafiadora | HSV, H 25–85, S 70–255, V 35–255 | 635.087 | 1.572.864 | 40,38% |

A queda da proporção da configuração HSV na imagem B, comparada ao limiar fixo invertido, indica que menos pixels escuros do fundo foram classificados como objeto. A proporção de HSV na imagem B ainda é elevada em parte pela folhagem e por outros tons verdes. **A proporção sozinha não prova que a máscara é mais correta**; essa interpretação depende da inspeção visual.

A validação programática foi feita pelo próprio programa e pelos testes:

- largura e altura da máscara iguais às da entrada;
- máscara 2D (um canal);
- conjunto de valores limitado a `{0, 255}`;
- saída em PNG sem perdas;
- contagem e proporção de primeiro plano impressas no terminal.

## 5. Discussão

### (a) Em que casos o limiar fixo falhou ou funcionou?

Na imagem A, o limiar fixo invertido recupera regiões escuras das maçãs, mas não acompanha os reflexos nem a variação interna de brilho; por isso, a máscara fica fragmentada. Na imagem B, falha de forma evidente: como grande parte da mesa de madeira e das sombras tem intensidade em cinza inferior a 140, elas viram primeiro plano e se conectam visualmente às maçãs. O resultado não separa cada fruto de maneira confiável.

### (b) Qual parâmetro foi mais sensível?

O limiar `--threshold` foi o mais sensível na configuração fixa. Mantendo os outros fatores constantes e variando o limiar invertido de 120 para 180, a proporção de primeiro plano na imagem A aumentou de **19,69% para 71,46%**; na imagem B aumentou de **78,01% para 89,60%**. Isso mostra que pequenas mudanças na fronteira de intensidade podem mudar substancialmente quanto do fundo é considerado objeto.

Na configuração HSV, a faixa de saturação também influencia o resultado, mas uma variação exploratória de `--smin` de 50 para 130 alterou a proporção de 30,17% para 25,71% na imagem A e de 41,04% para 36,25% na imagem B. Nesse conjunto, o limiar fixo apresentou a maior variação proporcional para o parâmetro testado.

### (c) Quais erros podem atrapalhar a contagem de objetos no M2.2?

- **Falsos positivos:** folhas verdes e regiões de fundo classificadas como verdes podem virar componentes extras e inflar a contagem.
- **Falsos negativos:** brilhos especulares, pontos com pouca saturação e partes sombreadas ou com cor fora do intervalo podem abrir buracos, dividir uma maçã em várias regiões ou apagar uma maçã pequena.
- **Objetos encostados:** se duas maçãs ou uma maçã e uma folha forem conectadas na máscara, o algoritmo de componentes conectados pode contá-las como um objeto só.
- **Ruído e fragmentação:** pequenas regiões isoladas podem ser contadas como objetos; buracos e bordas fragmentadas podem alterar a área e a forma dos componentes.

## 6. Configuração selecionada para M2.2

A configuração escolhida como ponto de partida é **HSV** (`H=25–85`, `S=70–255`, `V=35–255`). A classe foi definida por sua cor verde, de modo que HSV oferece um critério mais relacionado ao alvo do que a intensidade global em tons de cinza. Nas duas imagens, as maçãs permanecem discerníveis e o método é menos vulnerável ao fundo escuro da cena B.

A seleção não elimina falsos positivos nas folhas nem falsos negativos nos reflexos. Na próxima etapa, a contagem de componentes conectados deverá ser acompanhada de inspeção visual e, se necessário, refinamento dos limites HSV ou operações morfológicas. Esses refinamentos não foram aplicados neste marco para manter explícita a comparação básica entre os dois métodos.

## 7. Como reproduzir

Na raiz do projeto, execute os quatro comandos documentados no `README.md`. Para testar os casos mínimos:

```bash
python -m unittest discover -s tests -v
```

O teste sintético usa pixels `99`, `100` e `101` com `--threshold 100` e confirma que o limiar fixo normal produz `[0, 0, 255]`, incluindo o caso exatamente no limiar.
