@echo off
py "%~dp0pdi_lab.py" %*
exit /b %ERRORLEVEL%
