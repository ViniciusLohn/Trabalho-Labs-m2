# PDI Lab — M2.1: máscara binária e segmentação

Projeto de linha de comando em Python/OpenCV para segmentar maçãs verdes, gerar máscaras binárias sem perdas e medir a proporção de pixels classificados como primeiro plano. A implementação usa a interface comum `pdi_lab --input ... --output ... --operation segment --method ...`.

> **Imagens de entrada:** os arquivos em `images/input/` são mantidos sem alterações. A primeira cena contém três maçãs verdes sobre fundo neutro; a segunda contém cinco maçãs verdes sobre uma mesa de madeira, com sombras, reflexos e folhas.

## Requisitos

- Python 3.10 ou mais recente
- `numpy>=1.24`
- pacote de ligação OpenCV `opencv-python>=4.8` (testado com OpenCV 4.13.0 e NumPy 2.3.5)

Instale as dependências:

```bash
python -m pip install -r requirements.txt
```

A forma comum de invocação, válida a partir da raiz do projeto, é `python -m pdi_lab`. Em Windows, use `py -m pdi_lab`; em Linux/macOS, use `python3 -m pdi_lab` quando `python` não apontar para Python 3. Também estão disponíveis os lançadores `./pdi_lab` (Linux/macOS) e `pdi_lab.bat` (Windows).

Confira as opções suportadas com:

```bash
python -m pdi_lab --help
```

## Estrutura

```text
lab_m2_1_vinicius_lohn/
├── pdi_lab.py             # módulo/CLI
├── pdi_lab                # lançador POSIX
├── requirements.txt
├── README.md
├── REPORT.md              # mini relatório com figuras e métricas
├── AI_USAGE.md            # registro transparente de ferramentas de IA
├── lab.json               # metadados e parâmetros da M2.1
├── images/
│   ├── input/              # entradas originais, não alteradas
│   └── output/             # máscaras geradas em PNG
├── docs/                   # figuras de comparação e sobreposição
└── tests/
    └── test_pdi_lab.py
```

## Uso geral

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/mask.png --operation segment --method fixed --threshold 120
```

O programa retorna código `0` em sucesso e código diferente de `0` quando encontra falha de leitura, argumentos inválidos ou falha ao salvar. No terminal, informa dimensões, número de pixels de primeiro plano, proporção e validação binária.

## Métodos e parâmetros

- `fixed`: limiar global em escala de cinza. `--threshold` aceita inteiro de `0` a `255`. Sem `--invert`, valores maiores que o limiar viram `255`; com `--invert`, a polaridade é invertida (valores menores ou iguais ficam brancos).
- `otsu`: escolhe automaticamente o limiar global de Otsu; `--invert` também pode inverter a polaridade.
- `adaptive`: limiar adaptativo Gaussiano. `--block-size` é um inteiro ímpar `>=3` (janela local) e `--c` é uma constante não negativa subtraída da média local.
- `hsv`: seleciona um intervalo de cor no HSV do OpenCV. `--hmin` e `--hmax` variam de `0` a `179`; `--smin/--smax` e `--vmin/--vmax` variam de `0` a `255`. Se `--hmin > --hmax`, o código trata o intervalo como uma faixa que cruza a descontinuidade do matiz (junção dos intervalos `[hmin,179]` e `[0,hmax]`).
- `--blur`: desativa por padrão (`0`) ou aplica filtro Gaussiano antes da segmentação usando um kernel ímpar `>=3`. O valor escolhido precisa ser registrado no relatório.

Máscaras são salvas em PNG por padrão e o programa permite apenas formatos sem perdas (`.png`, `.tif`, `.tiff`, `.bmp`). A máscara é sempre 2D, de canal único, e usa exclusivamente os valores `0` e `255`.

## Comandos reproduzíveis usados neste relatório

**Configuração A — limiar fixo em cinza, limiar 140, invertido.** O caso escolhido tem maçãs mais escuras que algumas regiões do fundo na escala de cinza; a inversão é explicitada, embora sombras e madeira mostrem a limitação desse critério.

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/macas_favoravel_fixed.png --operation segment --method fixed --threshold 140 --invert
python -m pdi_lab --input images/input/macas_desafio.png --output images/output/macas_desafio_fixed.png --operation segment --method fixed --threshold 140 --invert
```

**Configuração B — intervalo HSV para verde.** Intervalo: `H=[25,85]`, `S=[70,255]`, `V=[35,255]` na escala HSV do OpenCV. Não foi aplicado filtro adicional (`--blur` permanece em `0`).

```bash
python -m pdi_lab --input images/input/macas_favoravel.png --output images/output/macas_favoravel_hsv.png --operation segment --method hsv --hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255
python -m pdi_lab --input images/input/macas_desafio.png --output images/output/macas_desafio_hsv.png --operation segment --method hsv --hmin 25 --hmax 85 --smin 70 --smax 255 --vmin 35 --vmax 255
```

As saídas `macas_favoravel_mask.png` e `macas_desafio_mask.png` são cópias exatas das máscaras HSV selecionadas como ponto de partida para M2.2.

## Testes

Execute da raiz do projeto:

```bash
python -m unittest discover -s tests -v
```

Os testes verificam: limiar fixo em uma imagem sintética com pixels abaixo, exatamente no e acima do limiar; execução dos dois métodos nas duas entradas; dimensões, canal único e valores `{0,255}`; falhas de leitura e gravação; método desconhecido; e limiar inválido.

## Escolha para M2.2

A configuração HSV é a escolhida como ponto de partida, porque a classe de interesse é definida pela cor verde e o método preserva melhor as regiões das maçãs nas duas cenas. Não é uma segmentação perfeita: folhas verdes na cena desafiadora podem gerar falsos positivos, e reflexos/pontos pouco saturados nos frutos podem virar falsos negativos. A contagem de objetos no M2.2 deve tratar componentes conectados e revisar esses erros antes de assumir que cada região branca corresponde a uma maçã.
