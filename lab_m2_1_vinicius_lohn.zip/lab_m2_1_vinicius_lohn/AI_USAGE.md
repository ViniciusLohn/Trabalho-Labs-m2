# Registro de uso de ferramentas de IA

utilizei as ferramenta de IA chat gpt, como apoio à estruturação e revisão do código.