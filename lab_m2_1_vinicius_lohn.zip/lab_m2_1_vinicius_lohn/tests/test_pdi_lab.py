from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "pdi_lab.py"
IMAGES = ROOT / "images" / "input"


class PdiLabCliTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )

    @staticmethod
    def base_args(input_path: Path, output_path: Path, method: str, *extra: str) -> list[str]:
        return [
            "--input", str(input_path),
            "--output", str(output_path),
            "--operation", "segment",
            "--method", method,
            *extra,
        ]

    def test_fixed_synthetic_threshold_includes_below_equal_above(self) -> None:
        # THRESH_BINARY do OpenCV define 0 para src <= threshold e 255 para src > threshold.
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            source = tmp / "limiar.png"
            output = tmp / "mascara.png"
            values = np.array([[99, 100, 101]], dtype=np.uint8)
            self.assertTrue(cv2.imwrite(str(source), values))
            result = self.run_cli(*self.base_args(source, output, "fixed", "--threshold", "100"))
            self.assertEqual(result.returncode, 0, result.stderr)
            mask = cv2.imread(str(output), cv2.IMREAD_UNCHANGED)
            self.assertIsNotNone(mask)
            self.assertEqual(mask.ndim, 2)
            self.assertEqual(mask.tolist(), [[0, 0, 255]])

    def test_two_input_images_with_fixed_and_hsv_and_binary_contract(self) -> None:
        for stem in ("macas_favoravel", "macas_desafio"):
            source = IMAGES / f"{stem}.png"
            original = cv2.imread(str(source), cv2.IMREAD_COLOR)
            self.assertIsNotNone(original, f"imagem não encontrada: {source}")
            configs = {
                "fixed": ["--threshold", "140", "--invert"],
                "hsv": ["--hmin", "25", "--hmax", "85", "--smin", "70", "--smax", "255", "--vmin", "35", "--vmax", "255"],
            }
            for method, extra in configs.items():
                with self.subTest(image=stem, method=method), tempfile.TemporaryDirectory() as td:
                    output = Path(td) / f"{stem}_{method}.png"
                    result = self.run_cli(*self.base_args(source, output, method, *extra))
                    self.assertEqual(result.returncode, 0, result.stderr)
                    mask = cv2.imread(str(output), cv2.IMREAD_UNCHANGED)
                    self.assertIsNotNone(mask)
                    self.assertEqual(mask.shape, original.shape[:2])
                    self.assertEqual(mask.ndim, 2)
                    self.assertTrue(set(np.unique(mask).tolist()).issubset({0, 255}))
                    self.assertIn("binary_validation=OK", result.stdout)

    def test_failed_read_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.base_args(Path(td) / "nao_existe.png", output, "fixed"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("não foi possível ler", result.stderr)

    def test_unknown_method_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.base_args(IMAGES / "macas_favoravel.png", output, "not-a-method"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("invalid choice", result.stderr)

    def test_invalid_parameter_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / "mask.png"
            result = self.run_cli(*self.base_args(IMAGES / "macas_favoravel.png", output, "fixed", "--threshold", "300"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("--threshold deve estar entre 0 e 255", result.stderr)

    def test_failed_write_returns_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            blocked_parent = tmp / "not_a_directory"
            blocked_parent.write_text("arquivo usado como diretório", encoding="utf-8")
            output = blocked_parent / "mask.png"
            result = self.run_cli(*self.base_args(IMAGES / "macas_favoravel.png", output, "fixed"))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("não foi possível preparar o diretório de saída", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
