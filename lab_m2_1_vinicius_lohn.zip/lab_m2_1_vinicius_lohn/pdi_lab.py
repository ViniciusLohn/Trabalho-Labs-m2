#!/usr/bin/env python3
"""pdi_lab: CLI para segmentação binária de imagens (Laboratório M2.1)."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

METHODS = ("fixed", "otsu", "adaptive", "hsv")


def _odd_kernel(value: int, name: str, allow_zero: bool = False) -> int:
    if allow_zero and value == 0:
        return value
    if value < 3 or value % 2 == 0:
        raise ValueError(f"{name} deve ser ímpar e >= 3" + (" ou 0" if allow_zero else ""))
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pdi_lab",
        description="Gera máscara binária para o Laboratório M2.1.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--input", required=True, help="caminho da imagem de entrada")
    parser.add_argument("--output", required=True, help="caminho da máscara de saída (PNG recomendado)")
    parser.add_argument("--operation", required=True, choices=("segment",), help="operação solicitada")
    parser.add_argument("--method", required=True, choices=METHODS, help="método de segmentação")
    parser.add_argument("--threshold", type=int, default=120, help="limiar global para fixed (0 a 255)")
    parser.add_argument("--invert", action="store_true", help="inverte a polaridade de fixed/otsu/adaptive")
    parser.add_argument("--block-size", type=int, default=11, help="janela ímpar para adaptive (>=3)")
    parser.add_argument("--c", type=float, default=2.0, help="constante subtraída da média local em adaptive")
    parser.add_argument("--hmin", type=int, default=25, help="matiz mínima HSV (0 a 179)")
    parser.add_argument("--hmax", type=int, default=85, help="matiz máxima HSV (0 a 179); hmin>hmax cruza 179/0")
    parser.add_argument("--smin", type=int, default=70, help="saturação mínima HSV (0 a 255)")
    parser.add_argument("--smax", type=int, default=255, help="saturação máxima HSV (0 a 255)")
    parser.add_argument("--vmin", type=int, default=35, help="valor/brilho mínimo HSV (0 a 255)")
    parser.add_argument("--vmax", type=int, default=255, help="valor/brilho máximo HSV (0 a 255)")
    parser.add_argument("--blur", type=int, default=0, help="kernel Gaussiano ímpar antes da segmentação; 0 desativa")
    return parser


def validate_args(args: argparse.Namespace) -> None:
    if not 0 <= args.threshold <= 255:
        raise ValueError("--threshold deve estar entre 0 e 255")
    _odd_kernel(args.blur, "--blur", allow_zero=True)
    if args.method == "adaptive":
        _odd_kernel(args.block_size, "--block-size")
    for name in ("hmin", "hmax"):
        value = getattr(args, name)
        if not 0 <= value <= 179:
            raise ValueError(f"--{name} deve estar entre 0 e 179 (faixa H do OpenCV)")
    for name in ("smin", "smax", "vmin", "vmax"):
        value = getattr(args, name)
        if not 0 <= value <= 255:
            raise ValueError(f"--{name} deve estar entre 0 e 255")
    if args.smin > args.smax:
        raise ValueError("--smin não pode ser maior que --smax")
    if args.vmin > args.vmax:
        raise ValueError("--vmin não pode ser maior que --vmax")
    if args.method == "adaptive" and args.c < 0:
        raise ValueError("--c deve ser maior ou igual a 0 neste projeto")


def segment_image(image: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    """Retorna máscara uint8 2D com valores exclusivos 0 e 255."""
    working = image
    if args.blur:
        working = cv2.GaussianBlur(working, (args.blur, args.blur), 0)

    if args.method == "hsv":
        hsv = cv2.cvtColor(working, cv2.COLOR_BGR2HSV)
        lower1 = np.array([args.hmin, args.smin, args.vmin], dtype=np.uint8)
        upper1 = np.array([args.hmax, args.smax, args.vmax], dtype=np.uint8)
        if args.hmin <= args.hmax:
            mask = cv2.inRange(hsv, lower1, upper1)
        else:
            # O matiz HSV é circular: unir os segmentos [hmin,179] e [0,hmax].
            upper_a = np.array([179, args.smax, args.vmax], dtype=np.uint8)
            lower_b = np.array([0, args.smin, args.vmin], dtype=np.uint8)
            mask_a = cv2.inRange(hsv, lower1, upper_a)
            mask_b = cv2.inRange(hsv, lower_b, upper1)
            mask = cv2.bitwise_or(mask_a, mask_b)
        return mask

    gray = cv2.cvtColor(working, cv2.COLOR_BGR2GRAY)
    if args.method == "fixed":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        _, mask = cv2.threshold(gray, args.threshold, 255, mode)
    elif args.method == "otsu":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        _, mask = cv2.threshold(gray, 0, 255, mode | cv2.THRESH_OTSU)
    elif args.method == "adaptive":
        mode = cv2.THRESH_BINARY_INV if args.invert else cv2.THRESH_BINARY
        mask = cv2.adaptiveThreshold(
            gray,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            mode,
            args.block_size,
            args.c,
        )
    else:  # Defesa adicional; argparse já restringe o método.
        raise ValueError(f"método desconhecido: {args.method}")
    return mask


def run(args: argparse.Namespace) -> int:
    validate_args(args)
    input_path = Path(args.input)
    output_path = Path(args.output)
    image = cv2.imread(str(input_path), cv2.IMREAD_COLOR)
    if image is None:
        raise OSError(f"não foi possível ler a imagem: {input_path}")
    if output_path.suffix.lower() not in {".png", ".tif", ".tiff", ".bmp"}:
        raise ValueError("a máscara deve ser salva em formato sem perdas: .png, .tif, .tiff ou .bmp")

    mask = segment_image(image, args)
    if mask.ndim != 2 or mask.shape != image.shape[:2]:
        raise RuntimeError("erro interno: dimensões/canais da máscara não correspondem à imagem")
    values = set(int(value) for value in np.unique(mask))
    if not values.issubset({0, 255}):
        raise RuntimeError(f"erro interno: máscara não binária: {sorted(values)}")

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise OSError(f"não foi possível preparar o diretório de saída '{output_path.parent}': {exc}") from exc
    if not cv2.imwrite(str(output_path), mask):
        raise OSError(f"não foi possível salvar a máscara: {output_path}")
    total = int(mask.size)
    foreground = int(cv2.countNonZero(mask))
    percentage = 100.0 * foreground / total if total else 0.0
    print(f"operation=segment method={args.method}")
    print(f"input={input_path} output={output_path}")
    print(f"width={image.shape[1]} height={image.shape[0]} channels=1")
    print(f"foreground_pixels={foreground} total_pixels={total} foreground_percent={percentage:.4f}")
    print(f"unique_values={sorted(values)} binary_validation=OK")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return run(args)
    except (OSError, ValueError, cv2.error) as exc:
        print(f"erro: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
