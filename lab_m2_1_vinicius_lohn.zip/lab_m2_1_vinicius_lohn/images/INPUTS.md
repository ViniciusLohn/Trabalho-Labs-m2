# Descrição das imagens de entrada

- `macas_favoravel.png`: três maçãs verdes sobre um fundo neutro, com iluminação suave e contraste relativamente uniforme.
- `macas_desafio.png`: cinco maçãs verdes sobre uma mesa de madeira, com sombras, reflexos, folhas e variação de iluminação.

Os arquivos em `images/input/` são usados sem alterações como entradas dos experimentos.
